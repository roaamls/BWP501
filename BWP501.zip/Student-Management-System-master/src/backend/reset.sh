php artisan cache:clear
php artisan config:clear
php artisan route:clear

php artisan migrate:refresh
php artisan passport:install
php artisan sms:setup

 php artisan sms:super
